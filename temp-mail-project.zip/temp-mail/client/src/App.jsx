import { useEffect, useState } from "react";
import { io } from "socket.io-client";
import api from "./api";

function App() {
  const [mailbox, setMailbox] = useState(null);
  const [messages, setMessages] = useState([]);
  const [loadingMailbox, setLoadingMailbox] = useState(false);
  const [loadingMessages, setLoadingMessages] = useState(false);

  const createMailbox = async () => {
    try {
      setLoadingMailbox(true);
      const res = await api.post("/api/mailbox");
      setMailbox(res.data);
      setMessages([]);
    } catch (err) {
      console.error(err);
      alert("สร้างอีเมลไม่สำเร็จ");
    } finally {
      setLoadingMailbox(false);
    }
  };

  const loadMessages = async () => {
    if (!mailbox) return;
    try {
      setLoadingMessages(true);
      const res = await api.get(`/api/mailbox/${mailbox.id}/messages`);
      setMessages(res.data);
    } catch (err) {
      console.error(err);
      alert("โหลดอีเมลไม่สำเร็จ");
    } finally {
      setLoadingMessages(false);
    }
  };

  useEffect(() => {
    if (!mailbox) return;

    const baseURL = import.meta.env.VITE_API_URL || window.location.origin;
    const socket = io(baseURL, {
      transports: ["websocket"]
    });

    socket.on("connect", () => {
      socket.emit("joinMailbox", mailbox.id);
    });

    socket.on("newMessage", (msg) => {
      setMessages((prev) => [msg, ...prev]);
    });

    socket.on("disconnect", () => {
      // console.log("socket disconnected");
    });

    return () => {
      socket.disconnect();
    };
  }, [mailbox]);

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#020617",
        color: "white",
        display: "flex",
        justifyContent: "center",
        padding: "2rem 1rem"
      }}
    >
      <div style={{ width: "100%", maxWidth: "800px" }}>
        <h1 style={{ fontSize: "2rem", fontWeight: "bold", marginBottom: "0.5rem" }}>
          Temp Mail Demo
        </h1>
        <p style={{ color: "#94a3b8", marginBottom: "1.5rem", fontSize: "0.9rem" }}>
          สร้างอีเมลชั่วคราว ใช้สมัครเว็บต่าง ๆ โดยไม่ต้องใช้อีเมลจริงของคุณ
        </p>

        <button
          onClick={createMailbox}
          disabled={loadingMailbox}
          style={{
            padding: "0.6rem 1.3rem",
            borderRadius: "999px",
            border: "none",
            background: "#0ea5e9",
            color: "#020617",
            fontWeight: 600,
            cursor: "pointer",
            marginBottom: "1rem"
          }}
        >
          {mailbox ? "สุ่มอีเมลใหม่" : "สร้างอีเมลชั่วคราว"}
        </button>

        {mailbox && (
          <div
            style={{
              marginBottom: "1.5rem",
              padding: "0.75rem 1rem",
              borderRadius: "0.75rem",
              background: "#020617",
              border: "1px solid #1e293b"
            }}
          >
            <p style={{ fontSize: "0.8rem", color: "#94a3b8", marginBottom: "0.25rem" }}>
              ที่อยู่อีเมลของคุณ
            </p>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                gap: "0.5rem"
              }}
            >
              <code
                style={{
                  fontFamily: "monospace",
                  fontSize: "0.9rem",
                  wordBreak: "break-all"
                }}
              >
                {mailbox.address}
              </code>
              <button
                onClick={() => navigator.clipboard.writeText(mailbox.address)}
                style={{
                  fontSize: "0.7rem",
                  padding: "0.3rem 0.7rem",
                  borderRadius: "999px",
                  border: "1px solid #1e293b",
                  background: "transparent",
                  color: "#38bdf8",
                  cursor: "pointer"
                }}
              >
                คัดลอก
              </button>
            </div>
            <p style={{ fontSize: "0.7rem", color: "#64748b", marginTop: "0.5rem" }}>
              หมดอายุใน: {new Date(mailbox.expiresAt).toLocaleString()}
            </p>
          </div>
        )}

        {mailbox && (
          <div>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: "0.5rem"
              }}
            >
              <h2 style={{ fontSize: "1rem", fontWeight: 600 }}>Inbox</h2>
              <button
                onClick={loadMessages}
                disabled={loadingMessages}
                style={{
                  fontSize: "0.7rem",
                  padding: "0.3rem 0.7rem",
                  borderRadius: "999px",
                  border: "1px solid #1e293b",
                  background: "transparent",
                  color: "#e2e8f0",
                  cursor: "pointer"
                }}
              >
                รีเฟรช
              </button>
            </div>

            {messages.length === 0 && (
              <p style={{ fontSize: "0.8rem", color: "#64748b" }}>
                ยังไม่มีอีเมล <br />
                ลองนำอีเมลนี้ไปใช้สมัครเว็บ / กดลืมรหัสผ่านจากเว็บอื่น
                แล้วกลับมาดูที่นี่อีกครั้ง
              </p>
            )}

            <div style={{ marginTop: "0.5rem", display: "flex", flexDirection: "column", gap: "0.5rem" }}>
              {messages.map((m) => (
                <div
                  key={m.id}
                  style={{
                    padding: "0.6rem 0.8rem",
                    borderRadius: "0.75rem",
                    background: "#020617",
                    border: "1px solid #1e293b"
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                      gap: "0.5rem"
                    }}
                  >
                    <p style={{ fontSize: "0.9rem", fontWeight: 600 }}>
                      {m.subject || "(ไม่มีหัวเรื่อง)"}
                    </p>
                    <span style={{ fontSize: "0.7rem", color: "#64748b" }}>
                      {m.receivedAt
                        ? new Date(m.receivedAt).toLocaleTimeString()
                        : ""}
                    </span>
                  </div>
                  <p style={{ fontSize: "0.75rem", color: "#94a3b8", marginTop: "0.15rem" }}>
                    จาก: {m.from}
                  </p>
                  {m.text && (
                    <p
                      style={{
                        fontSize: "0.75rem",
                        color: "#e2e8f0",
                        marginTop: "0.4rem",
                        whiteSpace: "pre-wrap"
                      }}
                    >
                      {m.text.length > 200 ? m.text.slice(0, 200) + "..." : m.text}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {!mailbox && (
          <p style={{ fontSize: "0.8rem", color: "#64748b", marginTop: "1rem" }}>
            กดปุ่ม "สร้างอีเมลชั่วคราว" เพื่อเริ่มต้นใช้งาน
          </p>
        )}
      </div>
    </div>
  );
}

export default App;
