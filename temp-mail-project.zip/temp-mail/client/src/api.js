import axios from "axios";

// If VITE_API_URL is set (e.g. http://localhost:4000) it will be used.
// Otherwise, relative URL will be used (same origin as frontend).
const API_URL = import.meta.env.VITE_API_URL || "";

const api = axios.create({
  baseURL: API_URL
});

export default api;
