import express from "express";
import Mailbox from "../models/Mailbox.js";
import Message from "../models/Message.js";

const router = express.Router();

function generateRandomLocalPart(length = 10) {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  let local = "";
  for (let i = 0; i < length; i++) {
    local += chars[Math.floor(Math.random() * chars.length)];
  }
  return local;
}

// POST /api/mailbox  → create new mailbox
router.post("/", async (req, res) => {
  try {
    const domain = process.env.MAIL_DOMAIN || "example.com";
    const localPart = generateRandomLocalPart();
    const address = `${localPart}@${domain}`;

    const ttlMinutes = Number(process.env.MAILBOX_TTL_MINUTES || 60);
    const now = new Date();
    const expiresAt = new Date(now.getTime() + ttlMinutes * 60 * 1000);

    const mailbox = await Mailbox.create({
      address,
      expiresAt
    });

    res.json({
      id: mailbox._id.toString(),
      address: mailbox.address,
      expiresAt: mailbox.expiresAt
    });
  } catch (err) {
    console.error("create mailbox error:", err);
    res.status(500).json({ error: "Failed to create mailbox" });
  }
});

// GET /api/mailbox/:id/messages  → list messages in mailbox
router.get("/:id/messages", async (req, res) => {
  try {
    const { id } = req.params;
    const messages = await Message.find({ mailboxId: id })
      .sort({ receivedAt: -1 })
      .lean();

    const formatted = messages.map((m) => ({
      id: m._id.toString(),
      from: m.from,
      to: m.to,
      subject: m.subject,
      text: m.text,
      html: m.html,
      receivedAt: m.receivedAt,
      isRead: m.isRead
    }));

    res.json(formatted);
  } catch (err) {
    console.error("fetch messages error:", err);
    res.status(500).json({ error: "Failed to fetch messages" });
  }
});

export default router;
