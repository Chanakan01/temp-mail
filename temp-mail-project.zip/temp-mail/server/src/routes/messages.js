import express from "express";
import Message from "../models/Message.js";

const router = express.Router();

// GET /api/messages/:id  → get a single message
router.get("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const msg = await Message.findById(id).lean();

    if (!msg) {
      return res.status(404).json({ error: "Message not found" });
    }

    res.json({
      id: msg._id.toString(),
      mailboxId: msg.mailboxId,
      from: msg.from,
      to: msg.to,
      subject: msg.subject,
      text: msg.text,
      html: msg.html,
      receivedAt: msg.receivedAt,
      isRead: msg.isRead
    });
  } catch (err) {
    console.error("get message error:", err);
    res.status(500).json({ error: "Failed to get message" });
  }
});

export default router;
