import Mailbox from "../models/Mailbox.js";
import Message from "../models/Message.js";

function extractEmail(value) {
  if (!value) return "";
  const str = String(value).trim();
  const match = str.match(/<(.+?)>/);
  return match ? match[1] : str;
}

export default async function inboundWebhook(req, res) {
  try {
    const io = req.app.get("io");

    console.log("📩 ThaiBulkSMS inbound payload:", req.body);

    const payload = req.body || {};

    const rawTo =
      payload.to_email ||
      payload.to ||
      payload.recipient ||
      payload.toAddress ||
      "";

    const rawFrom =
      payload.from_email ||
      payload.from ||
      payload.sender ||
      payload.fromAddress ||
      "";

    const subject =
      payload.subject ||
      payload.title ||
      payload.mail_subject ||
      "";

    const text =
      payload.text_body ||
      payload.text ||
      payload.body_text ||
      payload.body ||
      "";

    const html =
      payload.html_body ||
      payload.html ||
      payload.body_html ||
      "";

    const toEmail = extractEmail(rawTo);
    const fromEmail = extractEmail(rawFrom);

    if (!toEmail) {
      console.warn("⚠️ No 'to' email found in payload. Payload:", payload);
      return res.status(200).json({ status: "ignored_no_to_email" });
    }

    const mailbox = await Mailbox.findOne({
      address: toEmail,
      isActive: true
    });

    if (!mailbox) {
      console.warn("⚠️ No mailbox found for:", toEmail);
      return res.status(200).json({ status: "ignored_no_mailbox" });
    }

    const message = await Message.create({
      mailboxId: mailbox._id,
      from: fromEmail || "unknown@unknown",
      to: toEmail,
      subject: subject || "",
      text: text || "",
      html: html || ""
    });

    io.to(`mailbox:${mailbox._id.toString()}`).emit("newMessage", {
      id: message._id.toString(),
      from: message.from,
      to: message.to,
      subject: message.subject,
      text: message.text,
      receivedAt: message.receivedAt
    });

    return res.status(200).json({ status: "ok" });
  } catch (err) {
    console.error("❌ inbound webhook error:", err);
    return res.status(500).json({ error: "Webhook error" });
  }
}
