import mongoose from "mongoose";

const mailboxSchema = new mongoose.Schema({
  address: { type: String, unique: true, required: true }, // user123@domain
  userId: { type: String, default: null }, // optional, for future auth
  createdAt: { type: Date, default: Date.now },
  expiresAt: { type: Date, required: true },
  isActive: { type: Boolean, default: true }
});

// Auto delete document when expiresAt is reached
mailboxSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

const Mailbox = mongoose.model("Mailbox", mailboxSchema);
export default Mailbox;
