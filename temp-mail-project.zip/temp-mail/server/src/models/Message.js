import mongoose from "mongoose";

const messageSchema = new mongoose.Schema({
  mailboxId: { type: mongoose.Schema.Types.ObjectId, ref: "Mailbox", required: true },
  from: { type: String, required: true },
  to: { type: String, required: true },
  subject: { type: String, default: "" },
  text: { type: String, default: "" },
  html: { type: String, default: "" },
  receivedAt: { type: Date, default: Date.now },
  isRead: { type: Boolean, default: false }
});

const Message = mongoose.model("Message", messageSchema);
export default Message;
